﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace HttpModuleJasonTest
{
    public class HttpModuleJasonTest : IHttpModule
    {
        public HttpModuleJasonTest()
        {
        }

        public void Init(HttpApplication context)
        {

            context.ReleaseRequestState += new EventHandler(context_ReleaseRequestState);
        }

        void context_ReleaseRequestState(object sender, EventArgs e)
        {
            HttpContext.Current.Response.Filter = new Filter1(HttpContext.Current);
        }


        public void Dispose()
        {
        }
    }

    public class Filter1 : Stream
    {
        private HttpContext _context;
        private Stream _responseStream;
        private long _position;
        private StringBuilder _responseHtml;


        public Filter1(HttpContext context)
        {
            _context = context;
            _responseStream = _context.Response.Filter;
            _responseHtml = new StringBuilder();
        }
        #region Overrides
        public override bool CanRead
        {
            get { return _responseStream.CanRead; }
        }


        public override bool CanSeek
        {
            get { return _responseStream.CanSeek; }
        }


        public override bool CanWrite
        {
            get { return _responseStream.CanWrite; }
        }


        public override void Flush()
        {
            _responseStream.Flush();
        }


        public override long Length
        {
            get { return _responseStream.Length; }
        }


        public override long Position
        {
            get
            {
                return _responseStream.Position;
            }
            set
            {
                _responseStream.Position = value;
            }
        }


        public override void Close()
        {
            _responseStream.Close();
        }


        public override int Read(byte[] buffer, int offset, int count)
        {
            return _responseStream.Read(buffer, offset, count);
        }


        public override long Seek(long offset, System.IO.SeekOrigin origin)
        {
            return _responseStream.Seek(offset, origin);
        }


        public override void SetLength(long value)
        {
            _responseStream.SetLength(value);
        }
        #endregion


        public override void Write(byte[] buffer, int offset, int count)
        {
            string strBuffer = System.Text.UTF8Encoding.UTF8.GetString(buffer, offset, count);

            //log Response before modification to c:\temp\responseOutput.txt, need to create the file under c:\temp\ first.
            var fileStream = File.Open("C:\\Temp\\ResponseOutput.txt", FileMode.Append);
            fileStream.Write(buffer, 0, buffer.Length);
            byte[] newline = Encoding.ASCII.GetBytes(Environment.NewLine);
            fileStream.Write(newline, 0, newline.Length);
            fileStream.Write(newline, 0, newline.Length);
            fileStream.Close();


            Regex eof = new Regex("<head>", RegexOptions.IgnoreCase);


            if (eof.IsMatch(strBuffer))
            {
                _responseHtml.Append(strBuffer);
                string formHtml = _responseHtml.ToString();

                //replace <head> with <head><script>test.js</script>
                formHtml = formHtml.Replace("<head>","<head><script>test.js</script>");


                byte[] data = System.Text.UTF8Encoding.UTF8.GetBytes(formHtml);
                _responseStream.Write(data, 0, data.Length);
            }
            else
            {
                _responseHtml.Append(strBuffer);
            }
        }
    }

}
